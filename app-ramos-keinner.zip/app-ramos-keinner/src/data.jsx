export const productos = [
  {
    "id": 186,
    "title": "test3",
    "slug": "test3",
    "price": 1000,
    "   ": "lorem test",
    "category": {
      "id": 2,
      "name": "Electronics",
      "slug": "electronics",
      "image": "https://i.imgur.com/ZANVnHE.jpeg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-27T19:58:17.000Z"
    },
    "images": [
      "https://res.cloudinary.com/dfiui980m/image/upload/v1748450100/jwwchqqp2i0tpqxw6f34.jpg",
      "https://res.cloudinary.com/dfiui980m/image/upload/v1748450106/s36zjsh8rdcsjkfbwphd.jpg"
    ],
    "creationAt": "2025-05-28T16:35:30.000Z",
    "updatedAt": "2025-05-28T19:25:06.000Z"
  },
  {
    "id": 191,
    "title": "áo thun",
    "slug": "ao-thun",
    "price": 4,
    "description": "ngon ngot",
    "category": {
      "id": 4,
      "name": "Test title",
      "slug": "test-title",
      "image": "https://i.imgur.com/qNOjJje.jpeg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T18:23:22.000Z"
    },
    "images": [
      "https://images.unsplash.com/photo-1746647695879-bfab32f59f34?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"
    ],
    "creationAt": "2025-05-28T17:23:34.000Z",
    "updatedAt": "2025-05-28T17:23:34.000Z"
  },
  {
    "id": 198,
    "title": "New Product",
    "slug": "new-product",
    "price": 10,
    "description": "A description",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://images.unsplash.com/photo-1746647695879-bfab32f59f34?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"
    ],
    "creationAt": "2025-05-28T18:02:21.000Z",
    "updatedAt": "2025-05-28T18:59:33.000Z"
  },
  {
    "id": 200,
    "title": "RevoShop - American Professional II Stratocaster® HSS",
    "slug": "revoshop-american-professional-ii-stratocaster-hss",
    "price": 1200,
    "description": "The American Professional II Stratocaster® HSS draws from more than sixty years of innovation, inspiration and evolution to meet the demands of today's working player.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/lr7597x.png"
    ],
    "creationAt": "2025-05-28T18:22:30.000Z",
    "updatedAt": "2025-05-28T18:22:30.000Z"
  },
  {
    "id": 201,
    "title": "RevoShop - Player II Modified Stratocaster® - Sunburst",
    "slug": "revoshop-player-ii-modified-stratocaster-sunburst",
    "price": 1100,
    "description": "The Player II Modified Stratocaster® is a classic guitar with the modern player in mind. Sunburst finish adds a vintage touch to this modern instrument.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/BePqXpr.png"
    ],
    "creationAt": "2025-05-28T18:22:31.000Z",
    "updatedAt": "2025-05-28T18:22:31.000Z"
  },
  {
    "id": 202,
    "title": "RevoShop - Player II Modified Stratocaster® - Pearl",
    "slug": "revoshop-player-ii-modified-stratocaster-pearl",
    "price": 1300,
    "description": "The Player II Modified Stratocaster® is a classic guitar with the modern player in mind. Pearl finish adds a unique touch to this modern instrument.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/J9Kpem5.png"
    ],
    "creationAt": "2025-05-28T18:22:32.000Z",
    "updatedAt": "2025-05-28T18:22:32.000Z"
  },
  {
    "id": 203,
    "title": "RevoShop - Tash Sultana Stratocaster®",
    "slug": "revoshop-tash-sultana-stratocaster",
    "price": 1250,
    "description": "Tash Sultana's explosive loop-based performances, gorgeous layered guitar parts and jubilant leads rocketed the Melbourne artist from street busking to sold out shows - with a Fender in hand from the beginning.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/NOEQcdi.png"
    ],
    "creationAt": "2025-05-28T18:22:32.000Z",
    "updatedAt": "2025-05-28T18:22:32.000Z"
  },
  {
    "id": 204,
    "title": "RevoShop - Tom DeLonge Stratocaster®",
    "slug": "revoshop-tom-delonge-stratocaster",
    "price": 1150,
    "description": "Blink-182 guitarist Tom DeLonge has teamed up with Fender once again to release The Tom DeLonge Stratocaster®. This iconic Strat® makes a comeback just in time for Blink's reunion tour and the much-anticipated release of their latest album.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/M4Yt0L8.png"
    ],
    "creationAt": "2025-05-28T18:22:33.000Z",
    "updatedAt": "2025-05-28T18:22:33.000Z"
  },
  {
    "id": 205,
    "title": "RevoShop - Player II Modified Stratocaster® HSS Floyd Rose®",
    "slug": "revoshop-player-ii-modified-stratocaster-hss-floyd-rose",
    "price": 1150,
    "description": "The Player II Modified Stratocaster® HSS Floyd Rose® is a classic guitar with the modern player in mind. Floyd Rose® system allows for extreme whammy bar use without going out of tune.",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://i.imgur.com/m5DeCoc.png"
    ],
    "creationAt": "2025-05-28T18:22:33.000Z",
    "updatedAt": "2025-05-28T18:22:33.000Z"
  },
  {
    "id": 207,
    "title": "áo thun tay dài 123",
    "slug": "ao-thun-tay-dai-123",
    "price": 10,
    "description": "áo đẹp",
    "category": {
      "id": 5,
      "name": "Miscellaneous",
      "slug": "miscellaneous",
      "image": "https://i.imgur.com/BG8J0Fj.jpg",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-27T19:58:17.000Z"
    },
    "images": [
      "https://images.unsplash.com/photo-1746647695879-bfab32f59f34?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"
    ],
    "creationAt": "2025-05-28T18:59:00.000Z",
    "updatedAt": "2025-05-28T18:59:00.000Z"
  },
  {
    "id": 208,
    "title": "nombre unico",
    "slug": "nombre-unico",
    "price": 10,
    "description": "A description",
    "category": {
      "id": 1,
      "name": "hp2",
      "slug": "hp2",
      "image": "https://www.google.com/imgres?q=gambar%20admin&imgurl=https%3A%2F%2Fst2.depositphotos.com%2F1071184%2F6467%2Fv%2F450%2Fdepositphotos_64677535-stock-illustration-business-customer-care-service.jpg&imgrefurl=https%3A%2F%2Fdepositphotos.com%2Fid%2Fillustrations%2Fadmin.html&docid=cn69m4kNYq0lRM&tbnid=WvtsGak5gb8fZM&vet=12ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA..i&w=600&h=600&hcb=2&ved=2ahUKEwjstKG4vsCNAxUTTWwGHaD4GFMQM3oECFcQAA",
      "creationAt": "2025-05-27T19:58:17.000Z",
      "updatedAt": "2025-05-28T17:50:11.000Z"
    },
    "images": [
      "https://placehold.co/600x400"
    ],
    "creationAt": "2025-05-28T20:04:44.000Z",
    "updatedAt": "2025-05-28T20:04:44.000Z"
  }
]