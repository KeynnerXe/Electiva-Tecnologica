import React, { useState } from 'react';
import { productos } from './data';
import './App.css';

function Producto({ title, images, price, description, onClick, selected }) {
  return (
    <div
      className={`producto-card${selected ? ' selected' : ''}`}
      onClick={onClick}
      tabIndex={0}
      title="Agregar al carrito"
    >
      <img src={images[0]} alt={title} />
      <div>
        <h3>{title}</h3>
        <p className="precio">${price}</p>
        <p>{description}</p>
      </div>
    </div>
  );
}

function Carrito({ productos }) {
  const [hover, setHover] = useState(false);

  return (
    <div
      className={`carrito-flotante${hover ? ' abierto' : ''}`}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div className="carrito-header">
        <span role="img" aria-label="carrito">🛒</span>
        Carrito
        <span className="carrito-cantidad">{productos.length}</span>
      </div>
      {hover && (
        <div className="carrito-lista">
          {productos.length === 0 ? (
            <div className="carrito-vacio">No hay productos</div>
          ) : (
            productos.map((p, i) => (
              <div className="carrito-item" key={i}>
                {p.title} <span style={{ color: "#3a86ff" }}>${p.price}</span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [busqueda, setBusqueda] = useState('');
  const [carrito, setCarrito] = useState([]);
  const [destelloId, setDestelloId] = useState(null);

  const productosFiltrados = productos.filter(p =>
    p.title.toLowerCase().includes(busqueda.toLowerCase())
  );

  const agregarAlCarrito = (producto) => {
    setCarrito([...carrito, producto]);
    setDestelloId(producto.id);
    setTimeout(() => setDestelloId(null), 400);
  };

  return (
    <div>
      <Carrito productos={carrito} />
      <header className="header-tienda">
        <div className="logo-tienda">RopaShop</div>
        <nav>
          <a href="#inicio">Inicio</a>
          <a href="#catalogo">Catálogo</a>
          <a href="#contacto">Contáctanos</a>
        </nav>
        <input
          className="buscador"
          type="text"
          placeholder="Buscar producto..."
          value={busqueda}
          onChange={e => setBusqueda(e.target.value)}
        />
      </header>

      <section id="inicio" className="inicio-tienda">
        <h1>Bienvenido a RopaShop</h1>
        <p>La mejor tienda online de ropa moderna. Descubre nuestro catálogo exclusivo.</p>
      </section>

      <section id="catalogo" className="productos-container">
        <h2>Catálogo</h2>
        <div className="catalogo-grid">
          {productosFiltrados.length === 0 ? (
            <p className="no-resultados">No se encontraron productos.</p>
          ) : (
            productosFiltrados.map((producto) => (
              <Producto
                key={producto.id}
                {...producto}
                onClick={() => agregarAlCarrito(producto)}
                selected={destelloId === producto.id}
              />
            ))
          )}
        </div>
      </section>

      <footer id="contacto" className="footer-tienda">
        <h2>Contáctanos</h2>
        <p>Email: contacto@ropashop.com</p>
        <p>WhatsApp: +57 300 000 0000</p>
        <p>&copy; 2025 RopaShop. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}